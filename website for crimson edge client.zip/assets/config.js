window.CRIMSON_CONFIG = {
  // Replace these empty strings with your real URLs before publishing.
  downloadUrl: "",
  discordUrl: "",
  githubUrl: "",
  supportUrl: "",
  version: "0.7.0",
  minecraft: "1.21.11"
};