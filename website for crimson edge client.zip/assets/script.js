(() => {
  const cfg = window.CRIMSON_CONFIG || {};
  const qs = (s, r=document) => r.querySelector(s);
  const qsa = (s, r=document) => [...r.querySelectorAll(s)];

  const menu = qs(".menu-toggle");
  const nav = qs(".nav");
  if (menu && nav) {
    menu.addEventListener("click", () => {
      const open = nav.classList.toggle("open");
      menu.setAttribute("aria-expanded", String(open));
    });
    qsa(".nav a").forEach(a => a.addEventListener("click", () => {
      nav.classList.remove("open");
      menu.setAttribute("aria-expanded", "false");
    }));
  }

  qsa("[data-download]").forEach(a => {
    if (cfg.downloadUrl) {
      a.href = cfg.downloadUrl;
      a.target = "_blank";
      a.rel = "noopener";
    } else {
      a.addEventListener("click", e => {
        e.preventDefault();
        document.querySelector("#download")?.scrollIntoView({behavior:"smooth"});
      });
    }
  });

  const links = [
    ["[data-discord]", cfg.discordUrl],
    ["[data-github]", cfg.githubUrl],
    ["[data-support]", cfg.supportUrl]
  ];
  links.forEach(([selector,url]) => {
    const el = qs(selector);
    if (el && url) { el.href = url; el.target="_blank"; el.rel="noopener"; }
  });

  const note = qs("[data-config-note]");
  if (note && cfg.downloadUrl) note.textContent = `Current release: ${cfg.version || "latest"} · ${cfg.minecraft || "Minecraft 1.21.11"}`;

  qs("#year").textContent = new Date().getFullYear();

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) { entry.target.classList.add("visible"); observer.unobserve(entry.target); }
    });
  }, {threshold:.12});
  qsa(".reveal").forEach(el => observer.observe(el));

  // Keep browser navigation smooth without requiring a framework.
  window.addEventListener("pageshow", event => {
    if (event.persisted) document.documentElement.style.scrollBehavior = "smooth";
  });
})();