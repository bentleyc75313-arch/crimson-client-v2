# Crimson Edge Website

A lightweight, responsive static website for Crimson Edge.

## Included
- Responsive homepage for desktop, tablet, and mobile
- Clear download CTA
- Features, performance, cosmetics, launcher, and community sections
- No external runtime dependencies
- SVG favicon
- GitHub Pages workflow
- Central configuration in `assets/config.js`

## Configure links

Edit `assets/config.js`:

```js
window.CRIMSON_CONFIG = {
  downloadUrl: "YOUR_REAL_DOWNLOAD_URL",
  discordUrl: "YOUR_REAL_DISCORD_URL",
  githubUrl: "YOUR_REAL_GITHUB_URL",
  supportUrl: "YOUR_REAL_SUPPORT_URL",
  version: "0.7.0",
  minecraft: "1.21.11"
};
```

Do not leave placeholder URLs in production.

## GitHub Pages

1. Create a repository.
2. Upload the contents of this folder to the repository.
3. In **Settings → Pages**, select **GitHub Actions** as the source.
4. Push to `main`.
5. The included workflow publishes the site.

The workflow uses GitHub's Pages deployment actions. The site is plain static HTML/CSS/JS, so there is no build step.

## Notes

The performance and client descriptions are intentionally phrased without fabricated FPS benchmarks or unsupported guarantees. Add real benchmarks only when you have measured results you want to publish.

## System requirements

The website's requirements section uses Minecraft's current official Java Edition requirements:
- Minimum target: 1080p / 30 FPS / Fast
- Recommended target: 1080p / 60 FPS / Fancy
- Java 21 is called out for the Crimson Edge Minecraft 1.21.11 target setup.
- Fabric is identified as the client/mod-loader environment.

Source: https://www.minecraft.net/en-us/article/minecraft-java-edition-system-requirements
